Run task4_witherror.py or task5_witherror.py to produce the respective plots for tasks 4 or 5.
Run ising.animation.py from the commandline with parameters: N temp mode
Mode can be either 'kawasaki' or 'glauber'.